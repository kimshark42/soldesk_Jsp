package com.shark;

public class Shark {
	Shark shark = new Shark();
}
