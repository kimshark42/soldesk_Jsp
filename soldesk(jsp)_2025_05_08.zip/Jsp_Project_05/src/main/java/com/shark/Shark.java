package com.shark;

public class Shark {
	public String name = "SAY MY NAME!! 김상어!! 따이;;";
}
